import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AdminDashboard } from './pages/AdminDashboard';
import { StudentDirectory } from './pages/StudentDirectory';
import { RegistrationStep1 } from './pages/RegistrationStep1';
import { RegistrationStep2 } from './pages/RegistrationStep2';
import { RegistrationStep3 } from './pages/RegistrationStep3';

const AdminLayout = ({ children }) => {
  return <Layout>{children}</Layout>;
};

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Admin Portal Routes */}
        <Route path="/admin" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
        <Route path="/admin/students" element={<AdminLayout><StudentDirectory /></AdminLayout>} />

        {/* Placeholder routes for other admin pages */}
        <Route path="/admin/faculty" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">Faculty Management - Coming Soon</p></div></AdminLayout>} />
        <Route path="/admin/calendar" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">Academic Calendar - Coming Soon</p></div></AdminLayout>} />
        <Route path="/admin/financial" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">Financial Reports - Coming Soon</p></div></AdminLayout>} />
        <Route path="/admin/reports" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">Reports Hub - Coming Soon</p></div></AdminLayout>} />
        <Route path="/admin/requirements" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">Student Requirements - Coming Soon</p></div></AdminLayout>} />
        <Route path="/admin/settings" element={<AdminLayout><div className="text-center py-20"><p className="text-2xl">System Settings - Coming Soon</p></div></AdminLayout>} />

        {/* Registration Flow Routes */}
        <Route path="/registration/step1" element={<RegistrationStep1 />} />
        <Route path="/registration/step2" element={<RegistrationStep2 />} />
        <Route path="/registration/step3" element={<RegistrationStep3 />} />

        {/* Home/Welcome Page */}
        <Route path="/" element={<HomePage />} />

        {/* Default redirect */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

const HomePage = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-primary to-primary-container text-on-primary py-20">
        <div className="max-w-7xl mx-auto px-margin-desktop text-center">
          <div className="text-6xl mb-lg">🏫</div>
          <h1 className="font-headline-xl text-headline-xl mb-lg">Bridges Academy</h1>
          <p className="text-body-lg mb-lg">School Management System - React Edition</p>
          <p className="text-on-primary/80">A modern, responsive platform for educational administration</p>
        </div>
      </header>

      {/* Navigation Cards */}
      <div className="max-w-7xl mx-auto px-margin-desktop py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-lg mb-20">
          {/* Admin Portal */}
          <div className="card">
            <div className="text-5xl mb-lg">📊</div>
            <h2 className="font-headline-md text-headline-md text-primary mb-md">Admin Portal</h2>
            <p className="font-body-md text-body-md text-on-surface-variant mb-lg">
              Comprehensive administrative dashboard with student management, faculty oversight, financial tracking, and system analytics.
            </p>
            <div className="space-y-sm mb-lg">
              <a href="/admin" className="block text-primary font-label-md hover:underline">→ Dashboard</a>
              <a href="/admin/students" className="block text-primary font-label-md hover:underline">→ Student Directory</a>
              <a href="/admin/faculty" className="block text-primary font-label-md hover:underline">→ Faculty Management</a>
              <a href="/admin/calendar" className="block text-primary font-label-md hover:underline">→ Academic Calendar</a>
            </div>
            <a href="/admin" className="btn-primary inline-block">
              Go to Admin Portal
            </a>
          </div>

          {/* Registration */}
          <div className="card">
            <div className="text-5xl mb-lg">📝</div>
            <h2 className="font-headline-md text-headline-md text-primary mb-md">Student Registration</h2>
            <p className="font-body-md text-body-md text-on-surface-variant mb-lg">
              Streamlined multi-step registration workflow for new students with document management and verification system.
            </p>
            <div className="space-y-sm mb-lg">
              <p className="text-body-sm text-on-surface-variant">Step 1: Academic History</p>
              <p className="text-body-sm text-on-surface-variant">Step 2: Document Upload</p>
              <p className="text-body-sm text-on-surface-variant">Step 3: Review & Submit</p>
            </div>
            <a href="/registration/step1" className="btn-primary inline-block">
              Start Registration
            </a>
          </div>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
          <div className="card">
            <h3 className="font-headline-sm text-headline-sm text-primary mb-md">⚡ Fast & Responsive</h3>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Built with React and Tailwind CSS for optimal performance and responsive design.
            </p>
          </div>
          <div className="card">
            <h3 className="font-headline-sm text-headline-sm text-primary mb-md">🎨 Modern Design</h3>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Material Design 3 inspired system with consistent styling throughout.
            </p>
          </div>
          <div className="card">
            <h3 className="font-headline-sm text-headline-sm text-primary mb-md">📱 Mobile Ready</h3>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Fully responsive on mobile, tablet, and desktop devices.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 pt-20 border-t border-surface-variant text-center">
          <p className="font-body-sm text-on-surface-variant">
            Bridges Academy School Management System | React Edition v1.0
          </p>
          <p className="font-body-sm text-on-surface-variant mt-sm">
            Built for educational excellence and institutional efficiency
          </p>
        </div>
      </div>
    </div>
  );
};
