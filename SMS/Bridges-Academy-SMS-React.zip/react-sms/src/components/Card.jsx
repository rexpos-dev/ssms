export const Card = ({ children, className = '' }) => {
  return (
    <div className={`bg-surface-container-lowest border border-outline-variant p-lg rounded-xl shadow-[0_4px_20px_rgba(26,35,126,0.04)] ${className}`}>
      {children}
    </div>
  );
};

export const CardHeader = ({ title, subtitle, action }) => {
  return (
    <div className="pb-md border-b border-surface-variant flex justify-between items-start mb-lg">
      <div>
        <h3 className="font-headline-sm text-headline-sm text-primary">{title}</h3>
        {subtitle && <p className="text-body-sm text-on-surface-variant mt-xs">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
};

export const CardContent = ({ children, className = '' }) => {
  return <div className={className}>{children}</div>;
};

export const CardFooter = ({ children, className = '' }) => {
  return (
    <div className={`pt-lg border-t border-surface-variant flex gap-md justify-end ${className}`}>
      {children}
    </div>
  );
};

export default Card;
