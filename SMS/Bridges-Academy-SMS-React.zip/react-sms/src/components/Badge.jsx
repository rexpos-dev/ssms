export const Badge = ({ children, variant = 'primary', size = 'md' }) => {
  const variants = {
    primary: 'bg-primary-fixed text-on-primary-fixed-variant',
    success: 'bg-green-100 text-green-800',
    warning: 'bg-yellow-100 text-yellow-800',
    error: 'bg-error/10 text-error',
    secondary: 'bg-secondary-fixed text-on-secondary-fixed',
  };

  const sizes = {
    sm: 'px-xs py-xs text-label-sm',
    md: 'px-sm py-1 text-label-sm',
    lg: 'px-md py-sm text-body-sm',
  };

  return (
    <span className={`rounded font-label-md inline-block ${variants[variant]} ${sizes[size]}`}>
      {children}
    </span>
  );
};

export default Badge;
