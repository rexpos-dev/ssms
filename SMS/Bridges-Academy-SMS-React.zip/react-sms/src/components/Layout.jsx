import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar open={sidebarOpen} />
      <div className="flex-1 flex flex-col">
        <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
        <main className="flex-1 overflow-auto p-margin-desktop">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export const Sidebar = ({ open }) => {
  const navItems = [
    { label: 'Dashboard', href: '/admin', icon: 'dashboard' },
    { label: 'Student Directory', href: '/admin/students', icon: 'group' },
    { label: 'Faculty Management', href: '/admin/faculty', icon: 'badge' },
    { label: 'Academic Calendar', href: '/admin/calendar', icon: 'calendar_month' },
    { label: 'Financials', href: '/admin/financial', icon: 'payments' },
    { label: 'Reports', href: '/admin/reports', icon: 'assessment' },
    { label: 'Requirements', href: '/admin/requirements', icon: 'assignment_turned_in' },
    { label: 'Settings', href: '/admin/settings', icon: 'settings' },
  ];

  return (
    <aside className={`w-[260px] h-screen fixed left-0 top-0 bg-tertiary border-r border-outline-variant flex flex-col p-md z-50 transition-transform ${!open ? '-translate-x-full' : ''}`}>
      <div className="flex items-center gap-sm mb-xxl">
        <div className="w-10 h-10 bg-primary-container rounded flex items-center justify-center">
          <span className="text-on-primary-container text-xl">🏫</span>
        </div>
        <div>
          <h1 className="font-headline-sm text-headline-sm text-on-tertiary">Bridges Academy</h1>
          <p className="text-[10px] uppercase tracking-widest text-on-tertiary-container">Admin Portal</p>
        </div>
      </div>

      <nav className="flex-1 space-y-xs overflow-y-auto scrollbar-hide">
        {navItems.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            className="flex items-center gap-md px-md py-sm transition-colors duration-200 text-on-tertiary-container hover:bg-tertiary-container hover:text-on-tertiary rounded-lg"
          >
            <span>{item.icon}</span>
            <span className="font-label-md text-label-md">{item.label}</span>
          </Link>
        ))}
      </nav>

      <div className="mt-auto pt-md border-t border-tertiary-container">
        <button className="w-full bg-primary-container text-white py-sm rounded flex items-center justify-center gap-sm font-label-md text-label-md active:scale-95 transition-transform">
          + New Enrollment
        </button>
      </div>
    </aside>
  );
};

export const Header = ({ onMenuClick }) => {
  return (
    <header className="h-16 bg-surface border-b border-outline-variant flex justify-between items-center px-margin-desktop z-40 sticky top-0">
      <div className="flex items-center flex-1">
        <button onClick={onMenuClick} className="lg:hidden mr-md">
          <Menu size={24} />
        </button>
        <div className="relative w-full max-w-md">
          <span className="absolute left-md top-1/2 -translate-y-1/2 text-outline">🔍</span>
          <input
            className="w-full pl-xl pr-md py-xs bg-surface-container-low border border-outline-variant rounded-full font-body-md focus:outline-none focus:border-primary"
            placeholder="Search students, faculty, or records..."
            type="text"
          />
        </div>
      </div>

      <div className="flex items-center gap-lg ml-lg">
        <button className="relative text-on-surface-variant hover:text-primary transition-all">
          🔔
          <span className="absolute top-0 right-0 w-2 h-2 bg-error rounded-full"></span>
        </button>
        <button className="text-on-surface-variant hover:text-primary transition-all">⚡</button>
        <div className="h-8 w-[1px] bg-outline-variant"></div>
        <div className="flex items-center gap-sm">
          <div className="text-right">
            <p className="font-label-md text-label-md text-on-surface leading-tight">Admin User</p>
            <p className="text-[10px] text-on-surface-variant">Systems Overseer</p>
          </div>
          <img
            alt="Administrator"
            className="w-10 h-10 rounded-full border border-outline-variant object-cover"
            src="https://api.dicebear.com/7.x/avataaars/svg?seed=Administrator"
          />
        </div>
      </div>
    </header>
  );
};

export default Layout;
