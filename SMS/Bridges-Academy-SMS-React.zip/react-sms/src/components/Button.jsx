export const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  ...props
}) => {
  const baseClass = 'font-label-md rounded-lg transition-all active:scale-95';

  const variants = {
    primary: 'bg-primary text-on-primary hover:bg-primary-container',
    secondary: 'border border-secondary text-secondary hover:bg-secondary-container',
    text: 'text-primary hover:underline',
    danger: 'bg-error text-on-error hover:bg-error/90',
  };

  const sizes = {
    sm: 'px-sm py-xs text-label-sm',
    md: 'px-lg py-sm text-label-md',
    lg: 'px-xl py-md text-body-md',
  };

  return (
    <button
      className={`${baseClass} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
