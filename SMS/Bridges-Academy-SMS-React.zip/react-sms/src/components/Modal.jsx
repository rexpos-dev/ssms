import { X } from 'lucide-react';

export const Modal = ({ isOpen, onClose, title, children, actions }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-xl max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-lg">
          <h2 className="font-headline-sm text-headline-sm text-primary">{title}</h2>
          <button
            onClick={onClose}
            className="text-on-surface-variant hover:text-on-surface transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="mb-lg">
          {children}
        </div>

        {actions && (
          <div className="flex gap-md justify-end">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;
