import { useState } from 'react';
import { Card, CardHeader, CardContent, CardFooter, Input, Button } from '../components';
import { useNavigate } from 'react-router-dom';

export const RegistrationStep1 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dob: '',
    grade: '',
    previousSchool: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    // Save to session storage or state management
    sessionStorage.setItem('registrationStep1', JSON.stringify(formData));
    navigate('/registration/step2');
  };

  return (
    <div className="min-h-screen bg-background p-margin-desktop flex items-center justify-center">
      <Card className="max-w-2xl w-full">
        <CardHeader title="Student Registration" subtitle="Step 1 of 3: Academic History" />
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-md">
            <Input
              label="First Name"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              placeholder="Enter first name"
              required
            />
            <Input
              label="Last Name"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              placeholder="Enter last name"
              required
            />
            <Input
              label="Email Address"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="student@email.com"
              required
            />
            <Input
              label="Phone Number"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
              placeholder="+63-XXX-XXXX"
              required
            />
            <Input
              label="Date of Birth"
              name="dob"
              type="date"
              value={formData.dob}
              onChange={handleChange}
              required
            />
            <div>
              <label className="font-label-md text-label-md text-on-surface mb-sm block">Grade Level</label>
              <select
                name="grade"
                className="input-field"
                value={formData.grade}
                onChange={handleChange}
                required
              >
                <option value="">Select Grade</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>
            </div>
          </div>

          <Input
            label="Previous School Name"
            name="previousSchool"
            value={formData.previousSchool}
            onChange={handleChange}
            placeholder="Enter previous school name"
            className="mt-md"
          />
        </CardContent>
        <CardFooter>
          <Button variant="secondary">Cancel</Button>
          <Button onClick={handleNext}>Continue to Step 2</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default RegistrationStep1;
