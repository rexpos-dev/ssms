import { useState } from 'react';
import { Card, CardHeader, CardContent, Table, TableHead, TableBody, TableRow, TableHeader, TableCell, Badge, Input, Button } from '../components';

export const StudentDirectory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterGrade, setFilterGrade] = useState('');

  const students = [
    { id: 1, name: 'Elena Sterling', email: 'elena@school.edu', grade: '10', section: 'A', status: 'Active', phone: '+63-XXX-XXXX' },
    { id: 2, name: 'Marcus Chen', email: 'marcus@school.edu', grade: '11', section: 'B', status: 'Active', phone: '+63-XXX-XXXX' },
    { id: 3, name: 'Aria Thorne', email: 'aria@school.edu', grade: '9', section: 'C', status: 'Active', phone: '+63-XXX-XXXX' },
    { id: 4, name: 'Julian Ross', email: 'julian@school.edu', grade: '12', section: 'A', status: 'Graduated', phone: '+63-XXX-XXXX' },
    { id: 5, name: 'Sophie Martin', email: 'sophie@school.edu', grade: '10', section: 'B', status: 'Active', phone: '+63-XXX-XXXX' },
  ];

  const filteredStudents = students.filter(s =>
    (s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.email.includes(searchTerm)) &&
    (!filterGrade || s.grade === filterGrade)
  );

  return (
    <div>
      <div className="mb-xl">
        <h2 className="font-headline-xl text-headline-xl text-primary mb-lg">Student Directory</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
          <Input
            label="Search by name or email"
            placeholder="Elena Sterling, marcus@school.edu..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div>
            <label className="font-label-md text-label-md text-on-surface mb-sm block">Grade</label>
            <select
              className="input-field"
              value={filterGrade}
              onChange={(e) => setFilterGrade(e.target.value)}
            >
              <option value="">All Grades</option>
              <option value="9">Grade 9</option>
              <option value="10">Grade 10</option>
              <option value="11">Grade 11</option>
              <option value="12">Grade 12</option>
            </select>
          </div>
          <div className="flex items-end gap-md">
            <Button onClick={() => { setSearchTerm(''); setFilterGrade(''); }}>Reset</Button>
          </div>
        </div>
      </div>

      <Card>
        <CardContent>
          <Table>
            <TableHead>
              <TableRow>
                <TableHeader>Name</TableHeader>
                <TableHeader>Email</TableHeader>
                <TableHeader>Grade/Section</TableHeader>
                <TableHeader>Status</TableHeader>
                <TableHeader align="right">Action</TableHeader>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div>
                      <p className="font-body-md">{student.name}</p>
                      <p className="text-body-sm text-on-surface-variant">{student.phone}</p>
                    </div>
                  </TableCell>
                  <TableCell>{student.email}</TableCell>
                  <TableCell>{student.grade}-{student.section}</TableCell>
                  <TableCell>
                    <Badge variant={student.status === 'Active' ? 'success' : 'secondary'}>
                      {student.status}
                    </Badge>
                  </TableCell>
                  <TableCell align="right">
                    <button className="text-primary font-label-md hover:underline">View</button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="mt-lg text-center text-on-surface-variant">
        <p className="font-body-sm">Showing {filteredStudents.length} of {students.length} students</p>
      </div>
    </div>
  );
};

export default StudentDirectory;
